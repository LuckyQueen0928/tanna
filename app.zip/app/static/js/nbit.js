// $("form#data").submit(function(){
//     var formData = new FormData($(this)[0]);
//     $.ajax({
//         url: '/newtask/net-upload',
//         type: 'POST',
//         data: formData,
//         async: false,
//         success: function (data) {
//             alert(data)
//         },
//         cache: false,
//         contentType: false,
//         processData: false
//     });
//     return false;
// });
